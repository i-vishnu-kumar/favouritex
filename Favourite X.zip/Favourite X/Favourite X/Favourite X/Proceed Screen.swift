//
//  Proceed Screen.swift
//  Favourite X
//
//  Created by Kumar, Vishnu | Vishnu | RMI on 2025/01/31.
//

import SwiftUI

struct Proceed_Screen: View {
    @State private var nextLevel = false
    let imageURL = URL(string: "https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExcjVvYW5ueWUwajdwMHVwdzN5eWpqMGhuZXpwdGRnZGM1NWFlODFmZCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/9xt1MUZqkneFiWrAAD/giphy.gif")!

    var body: some View {
        if nextLevel {
            Level2()
        }
        else {
            AsyncImage(url: imageURL) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .gray))
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()
                        .clipped()
                        .padding()
                case .failure(_):
                    Text("Failed to load image")
                @unknown default:
                    Text("Unknown error")
                }
            }
            Spacer()
            Text("Hurrah, you passed!!!")
                .font(.largeTitle)
                .bold()
            
            Text("Ofcourse no one should be a crush, must be many...")
                .bold()
                .foregroundStyle(.orange)
                .font(.title3)
            
            Spacer()
            
            HStack {
                Spacer()
                Text("Proceed ")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.white)
                
                
                Image(systemName: "forward")
                Spacer()
            }
            .background(LinearGradient(gradient: Gradient(colors: [Color.pink, Color.purple]), startPoint: .top, endPoint: .bottom))
            .cornerRadius(25)
            .shadow(radius: 10)
            .scaleEffect(1.1)
            .padding(.horizontal, 50)
            .padding(.bottom, 30)
            .onTapGesture {
                SoundManager.shared.playButtonClickSound()
                nextLevel = true
            }
        }
    }
}

#Preview {
    Proceed_Screen()
}
