//
//  Favourite_XApp.swift
//  Favourite X
//
//  Created by Kumar, Vishnu | Vishnu | RMI on 2025/01/31.
//

import SwiftUI

@main
struct Favourite_XApp: App {
    
    init() {
        // Start the background music as soon as the app launches
        SoundManager.shared.playBackgroundMusic()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
