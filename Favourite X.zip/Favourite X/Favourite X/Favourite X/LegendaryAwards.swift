import SwiftUI

struct LegendaryAwards: View {
    @State private var nextLevel = false
    var body: some View {
        if (nextLevel) {UnderConstruction()}
        else {
            ZStack {
                
                LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.4)]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 20) {
                    HStack {
                        Text("🎉")
                            .font(.system(size: 200, weight: .bold, design: .rounded))
                            .rotationEffect(Angle(degrees: 80))
                        
                        Spacer()
                        
                        Text("🎉")
                            .font(.system(size: 200, weight: .bold, design: .rounded))
                            .rotationEffect(Angle(degrees: 180))
                    }
                    Spacer()
                    
                    Text("You win an online order ")
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .foregroundColor(.green)
                        .multilineTextAlignment(.center)
//                        .padding(.horizontal, 40)
                        .padding(.top, 50)
                        .padding(.bottom, -20)
                    
                    HStack {
                        Text("🎉")
                        
                        Text("worth ₹2,500")
                            .font(.system(size: 32, weight: .bold, design: .rounded))
                            .foregroundColor(.green)
                            .multilineTextAlignment(.center)
                        //                        .padding(.horizontal, 40)
                        //                        .padding(.top, 50)
                        
                        Text("🎉")
                            .rotationEffect(Angle(degrees: -80))
                    }
                    
                    Text("Contact your boyfriend")
                        .font(.system(size: 22, weight: .regular, design: .rounded))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
//                        .padding(.horizontal, 40)
                        .padding(.top, 25)
                        .padding(.bottom, -20)
                    
                    Text("for further details!")
                        .font(.system(size: 22, weight: .regular, design: .rounded))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
//                        .padding(.horizontal, 40)
//                        .padding(.top, 25)
                    Spacer()
                    
                    Text("PS: Don't forget to share the screenshot of this page.")
                        .font(.system(size: 22, weight: .light, design: .rounded))
                        .foregroundColor(.pink)
                        .italic()
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 40)
                    
                    Button(action: {
                        print("Button tapped!")
                    }) {
                        Text("What's more")
                            .font(.title2)
                            .bold()
                            .padding()
                            .foregroundColor(.white)
                            .background(LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]), startPoint: .leading, endPoint: .trailing))
                            .cornerRadius(25)
                            .shadow(radius: 10)
                            .padding(.top, 40)
                            .onTapGesture{
                                SoundManager.shared.playWishesSound()
                                nextLevel = true
                            }
                    }
                    
                }
                .padding()
            }
        }
    }
}

#Preview {
    LegendaryAwards()
}
