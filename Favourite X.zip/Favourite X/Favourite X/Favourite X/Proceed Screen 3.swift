//
//  Proceed Screen 3.swift
//  Favourite X
//
//  Created by Kumar, Vishnu | Vishnu | RMI on 2025/02/01.
//

import SwiftUI

struct Proceed_Screen_3: View {
    @State private var nextLevel = false
    let imageURL = URL(string: "https://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExMjZ3eHNpdmxseG85cGxhbnBuNGh4dms2b2VwZmc0aGV6bDZneWVqNCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/bw7YiaWNDPXFUlmh0Y/giphy.gif")!

    var body: some View {
        if nextLevel {
            UnderConstruction()
        }
        else {
            AsyncImage(url: imageURL) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .gray))
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()
                        .clipped()
                        .padding()
                case .failure(_):
                    Text("Failed to load image")
                @unknown default:
                    Text("Unknown error")
                }
            }
            Spacer()
            Text("That's an impressive victory!!! 🥰")
                .font(.system(size: 25))
//                .font(.largeTitle)
                .bold()
            
            Text("Such a great victory for you...")
                .foregroundStyle(.orange)
                .bold()
                .font(.title3)
            
            Text("You deserve this ➡")
                .foregroundStyle(.orange)
                .bold()
                .font(.title3)
            
            Spacer()
            
            HStack {
                Spacer()
                Text("Proceed ")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.white)
                
                
                Image(systemName: "forward")
                Spacer()
            }
            .background(LinearGradient(gradient: Gradient(colors: [Color.pink, Color.purple]), startPoint: .top, endPoint: .bottom))
            .cornerRadius(25)
            .shadow(radius: 10)
            .scaleEffect(1.1)
            .padding(.horizontal, 50)
            .padding(.bottom, 30)
            .onTapGesture {
                SoundManager.shared.playWinSound()
                nextLevel = true
            }
        }
    }
}

#Preview {
    Proceed_Screen_3()
}
