//
//  RapidFire_a.swift
//  Favourite X
//
//  Created by Kumar, Vishnu | Vishnu | RMI on 2025/02/01.
//

import SwiftUI

struct RapidFire_a: View {
    @State private var timer: Int = 5
    @State private var timerRunning = true
    @State private var wrong = ""
    @State private var wrongPressed = false
    @State private var retryScreen: Bool = false
    
    let timerPublisher = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        if (retryScreen) { RapidFireRound_pr_a() }
        else if (timerRunning && wrongPressed == false && wrong == "Correct") {RapidFire_b() }
        else {
            VStack {
                Text("This is Rapid Fire round")
                    .font(.largeTitle)
                    .bold()
                
                HStack {
                    Text("1/3")
                        .foregroundStyle(.brown)
                        .bold()
                        .font(.title)
                        
                    Spacer()
                    Text("Timer: \(timer) sec")
                        .foregroundStyle(.red)
                        .font(.title)
                        .bold()
                }
                .padding()
                
                Rectangle()
                    .frame(maxHeight: 2)
            }.onReceive(timerPublisher) { _ in
                if timerRunning && timer > 0 && wrong != "Wrong" {
                    timer -= 1
                } else {
                    timerRunning = false
                }
            }
            HStack {
                VStack(alignment: .leading) {
                    Text("When should you come to Japan: -")
//                        .foregroundStyle(.green)
                        .font(.largeTitle)
                        .padding(.vertical, 35)
                        .bold()
                    
                    Text("A: When you crack the dunky route.")
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .foregroundStyle(.yellow)
                        .onTapGesture{
                            wrong = "Wrong"
                            wrongPressed = true
                            SoundManager.shared.playButtonClickSound()
                        }
                    
                    Spacer()
                    Text("B: As soon as possible.")
                        .foregroundStyle(.orange)
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .onTapGesture{
                            wrong = "Correct"
                            SoundManager.shared.playButtonClickSound()
                        }
                    
                    Spacer()
                    Text("C: When you get a job.")
                        .foregroundStyle(.blue)
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .onTapGesture{
                            wrong = "Wrong"
                            wrongPressed = true
                            SoundManager.shared.playButtonClickSound()
                        }
                    
                    Spacer()
                    Text("D: When the weather is good.")
                        .foregroundStyle(.purple)
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .onTapGesture{
                            wrong = "Wrong"
                            wrongPressed = true
                            SoundManager.shared.playButtonClickSound()
                        }
                    
                    Spacer()
                    
                    if (wrong == "Wrong" || timerRunning == false) {
                        Text("Retry")
                            .font(.title2)
                            .padding()
                            .foregroundColor(.white)
                            .background(LinearGradient(gradient: Gradient(colors: [Color.pink, Color.purple]), startPoint: .top, endPoint: .bottom))
                            .cornerRadius(25)
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .padding()
                            .shadow(radius: 10)
                            .scaleEffect(1.1)
                            .onTapGesture{
                                SoundManager.shared.playButtonClickSound()
                                retryScreen = true;
                            }
                        
                    }
                    
                }
                .padding(.horizontal, 50)
                Spacer()
                
            }
            
        }
    }
}

#Preview {
    RapidFire_a()
}
