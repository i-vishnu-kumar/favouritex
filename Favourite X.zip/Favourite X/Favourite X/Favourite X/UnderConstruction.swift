//
//  Level2.swift
//  Favourite X
//
//  Created by Kumar, Vishnu | Vishnu | RMI on 2025/01/31.
//

import SwiftUI

struct UnderConstruction: View {
    @State private var nextLevel = false
    let imageURL = URL(string: "https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExZDYzM3l0aGE3cTgxYXl6eDFiaXBlZHB5cHk3YThrb2xscnZsZXpzZiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/l3vQYe7l1TInypnYA/giphy.gif")!

    var body: some View {
        if nextLevel {
            ContentView()
        }
        else {
            AsyncImage(url: imageURL) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .gray))
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()
                        .clipped()
                        .padding()
                case .failure(_):
                    Text("Failed to load image")
                @unknown default:
                    Text("Unknown error")
                }
            }
            Spacer()
            
            Text("⚠️ Sorry no further levels for now ⚠️")
//                .font(.title)
                .font(.system(size: 20, weight: .bold, design: .rounded))
                .bold()
                .foregroundStyle(.secondary)
                .padding()
            
            VStack (alignment: .center){
                Text(" Happy ")
                    .font(.system(size: 36, weight: .bold, design: .rounded))
                    .fontWeight(.bold)
                HStack {
                    Text("🎉")
                    
                    Text(" Friendship ")
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                        .fontWeight(.bold)
                    
                    Text("🎉")
                        .rotationEffect(Angle(degrees: -80))
                }
                Text(" Day! ")
                    .font(.system(size: 36, weight: .bold, design: .rounded))
                    .fontWeight(.bold)
               
            }
                .font(.largeTitle)
                .bold()
            
            Spacer()
            
            HStack {
                Spacer()
                Text("Home Screen ")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.white)
                
                
                Image(systemName: "externaldrive.connected.to.line.below")
                Spacer()
            }
            .background(LinearGradient(gradient: Gradient(colors: [Color.pink, Color.purple]), startPoint: .top, endPoint: .bottom))
            .cornerRadius(25)
            .shadow(radius: 10)
            .scaleEffect(1.1)
            .padding(.horizontal, 50)
            .padding(.bottom, 30)
            .onTapGesture {
                SoundManager.shared.playButtonClickSound()
                nextLevel = true
            }
        }
    }
}

#Preview {
    UnderConstruction()
}
