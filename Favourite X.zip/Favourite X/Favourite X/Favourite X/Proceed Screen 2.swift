//
//  Proceed Screen 2.swift
//  Favourite X
//
//  Created by Kumar, Vishnu | Vishnu | RMI on 2025/01/31.
//

import SwiftUI

struct Proceed_Screen_2: View {
    @State private var nextLevel = false
    let imageURL = URL(string: "https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExc3ExbmI4OHp5cDMwaTVjcWp1dGdsaXF5MTMweDk5bHhmc2tqem5wZSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/qTeCS8pvoELD6mMsme/giphy.gif")!

    var body: some View {
        if nextLevel {
            RapidFireRound_pr_a()
        }
        else {
            AsyncImage(url: imageURL) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .gray))
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()
                        .clipped()
                        .padding()
                case .failure(_):
                    Text("Failed to load image")
                @unknown default:
                    Text("Unknown error")
                }
            }
            Spacer()
            Text("Wow, you passed again!!! 🔥")
                .font(.system(size: 25))
//                .font(.largeTitle)
                .bold()
            
            Text("Because I'm much more important...")
                .foregroundStyle(.orange)
                .bold()
                .font(.title3)
            
            Spacer()
            
            HStack {
                Spacer()
                Text("Proceed ")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.white)
                
                
                Image(systemName: "forward")
                Spacer()
            }
            .background(LinearGradient(gradient: Gradient(colors: [Color.pink, Color.purple]), startPoint: .top, endPoint: .bottom))
            .cornerRadius(25)
            .shadow(radius: 10)
            .scaleEffect(1.1)
            .padding(.horizontal, 50)
            .padding(.bottom, 30)
            .onTapGesture {
                SoundManager.shared.playButtonClickSound()
                nextLevel = true
            }
        }
    }
}

#Preview {
    Proceed_Screen_2()
}
