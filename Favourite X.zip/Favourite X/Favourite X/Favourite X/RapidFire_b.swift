//
//  RapidFire_b.swift
//  Favourite X
//
//  Created by Kumar, Vishnu | Vishnu | RMI on 2025/02/01.
//

import SwiftUI

struct RapidFire_b: View {
    @State private var timer: Int = 5
    @State private var timerRunning = true
    @State private var wrong = ""
    @State private var wrongPressed = false
    @State private var retryScreen: Bool = false
    
    let timerPublisher = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        if (retryScreen) { RapidFireRound_pr_a() }
        else if (timerRunning && wrongPressed == false && wrong == "Correct") {RapidFire_c() }
        else {
            VStack {
                Text("This is Rapid Fire round")
                    .font(.largeTitle)
                    .bold()
                
                HStack {
                    Text("2/3")
                        .foregroundStyle(.brown)
                        .bold()
                        .font(.title)
                        
                    Spacer()
                    Text("Timer: \(timer) sec")
                        .foregroundStyle(.red)
                        .font(.title)
                        .bold()
                }
                .padding()
                
                Rectangle()
                    .frame(maxHeight: 2)
            }.onReceive(timerPublisher) { _ in
                if timerRunning && timer > 0 && wrong != "Wrong" {
                    timer -= 1
                } else {
                    timerRunning = false
                }
            }
            HStack {
                VStack(alignment: .leading) {
                    Text("Which is the best change to do in yourself: -")
                        .font(.largeTitle)
                        .padding(.vertical, 35)
                        .bold()
                    
                    Text("A: Reduce your expenditures a lot.")
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .foregroundStyle(.yellow)
                        .onTapGesture{
                            wrong = "Wrong"
                            wrongPressed = true
                            SoundManager.shared.playButtonClickSound()
                        }
                    
                    Spacer()
                    Text("B: Start Eating Lesser.")
                        .foregroundStyle(.orange)
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .onTapGesture{
                            wrong = "Wrong"
                            wrongPressed = true
                            SoundManager.shared.playButtonClickSound()
                        }
                    
                    Spacer()
                    Text("D: Send me money each day.")
                        .foregroundStyle(.blue)
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .onTapGesture{
                            wrong = "Correct"
                            SoundManager.shared.playButtonClickSound()
                        }
                    
                    
                    Spacer()
                    Text("C: Pay respect to things around you.")
                        .foregroundStyle(.purple)
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .onTapGesture{
                            wrong = "Wrong"
                            wrongPressed = true
                            SoundManager.shared.playButtonClickSound()
                        }
                    
                    
                    Spacer()
                    
                    if (wrong == "Wrong" || timerRunning == false) {
                        Text("Retry")
                            .font(.title2)
                            .padding()
                            .foregroundColor(.white)
                            .background(LinearGradient(gradient: Gradient(colors: [Color.pink, Color.purple]), startPoint: .top, endPoint: .bottom))
                            .cornerRadius(25)
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .padding()
                            .shadow(radius: 10)
                            .scaleEffect(1.1)
                            .onTapGesture{
                                SoundManager.shared.playButtonClickSound()
                                retryScreen = true;
                            }
                        
                    }
                    
                }
                .padding(.horizontal, 50)
                Spacer()
                
            }
            
        }
    }
}
#Preview {
    RapidFire_b()
}
