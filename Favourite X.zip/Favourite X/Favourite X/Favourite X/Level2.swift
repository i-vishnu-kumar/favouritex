//
//  Level2.swift
//  Favourite X
//
//  Created by Kumar, Vishnu | Vishnu | RMI on 2025/01/31.
//

import SwiftUI

struct Level2: View {
    let imageURL = URL(string: "https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExY3ozbnQzcThhbWp2dm53eTUzY3V1bm9vcTA0MDloMHJrcHB2dW5pbiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/oaZ2J3kAt6fqM5b00w/giphy.gif")!
    
    let imageURL2 = URL(string: "https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExNnJyaHkwNzZ3cHdrd3htYTM3a2ppOTh6MXJuOTgyaWJ1czd1cXYzZSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/VbnUQpnihPSIgIXuZv/giphy.gif")!
    
    @State private var levelPassed: Bool = false
    @State private var levelFailed: Bool = false
    
    var body: some View {
        if (levelFailed) {LoserView()}
        else if (levelPassed) {Proceed_Screen_2()}
        else {
            Text("Which one is important ??")
                .font(.largeTitle)
                .bold()
            HStack {
                VStack {
                    Text("1")
                        .font(.largeTitle)
                        .bold()
                    
                    AsyncImage(url: imageURL) { phase in
                        switch phase {
                        case .empty:
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .gray))
                        case .success(let image):
                            image
                                .resizable()
                                .scaledToFit()
                                .clipped()
                                .padding()
                        case .failure(_):
                            Text("Failed to load image")
                        @unknown default:
                            Text("Unknown error")
                        }
                    }
                    
                    Text("Chicken Biryani!!! 😋")
                        .bold()
                }
                .onTapGesture {
                    SoundManager.shared.playLooseSound()
                    levelFailed = true
                }
                
                Rectangle()
                    .frame(width: 1)
                
                VStack {
                    Text("2")
                        .font(.largeTitle)
                        .bold()
                    
                    AsyncImage(url: imageURL2) { phase in
                        switch phase {
                        case .empty:
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .gray))
                        case .success(let image):
                            image
                                .resizable()
                                .scaledToFit()
                                .clipped()
                                .padding()
                        case .failure(_):
                            Text("Failed to load image")
                        @unknown default:
                            Text("Unknown error")
                        }
                    }
                    
                    Text("Me, your friend 😍")
                        .bold()
                }.onTapGesture {
                    SoundManager.shared.playWinSound()
                    levelPassed = true
                }
            }
        }
    }
}

#Preview {
    Level2()
}
