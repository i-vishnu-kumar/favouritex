import SwiftUI

struct RapidFireRound_pr_a: View {
    @State private var timer: Int = 5
    @State private var timerRunning = false
    @State private var timerGetReady = 3
    @State private var isLevelReady = false
    
    let timerPublisher = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        if (isLevelReady) { RapidFire_a() }
        else {
            VStack {
                Text("This is Rapid Fire round")
                    .font(.largeTitle)
                    .bold()
                
                HStack {
                    Spacer()
                    Text("Timer: \(timer) sec")
                        .foregroundStyle(.red)
                        .font(.title)
                        .bold()
                }
                .padding()
                
                Spacer()
                
                Text("\(timerGetReady)")
                    .bold()
                    .font(.system(size: 300))
                    .foregroundStyle(.pink)
                
                Text("Get Ready 🫡")
                    .font(.largeTitle)
                    .bold()
                
                Spacer()
            }
            .onReceive(timerPublisher) { _ in
                if (timerGetReady == 0) {
                    isLevelReady = true
                }
                if timerGetReady > 0 {
                    SoundManager.shared.playButtonClickSound()
                    timerGetReady -= 1
                }
                if timerRunning && timer > 0 {
                    timer -= 1
                } else {
                    timerRunning = false
                }
            }
        }
    }
}

#Preview {
    RapidFireRound_pr_a()
}
