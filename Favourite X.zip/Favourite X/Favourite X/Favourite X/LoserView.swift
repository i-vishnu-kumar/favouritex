import SwiftUI

struct LoserView: View {
    @State private var retried = false
    let imageURL = URL(string: "https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExaXE5NWVmcGdrd2FwYjB4OTlub253eG1wZXJqdmc3M3k0a2ZsYXVwOSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/rKj0oXtnMQNwY/giphy.gif")!

    var body: some View {
        if retried {
            ContentView()
        }
        else {
            AsyncImage(url: imageURL) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .gray))
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()
                        .clipped()
                        .padding()
                case .failure(_):
                    Text("Failed to load image")
                @unknown default:
                    Text("Unknown error")
                }
            }
            Spacer()
            Text("You Failed!!! 😒")
                .font(.largeTitle)
                .bold()
            
            Spacer()
            
            HStack {
                Spacer()
                Text("Retry ")
                    .font(.title2)
                    .padding()
                //                .padding(.horizontal, 50)
                    .foregroundColor(.white)
                
                
                Image(systemName: "arrow.trianglehead.counterclockwise.rotate.90")
                Spacer()
            }
            .background(LinearGradient(gradient: Gradient(colors: [Color.pink, Color.purple]), startPoint: .top, endPoint: .bottom))
            .cornerRadius(25)
            .shadow(radius: 10)
            .scaleEffect(1.1)
            .padding(.horizontal, 50)
            .padding(.bottom, 30)
            .onTapGesture {
                SoundManager.shared.playButtonClickSound()
                retried = true
            }
        }
    }
}

#Preview {
    LoserView()
}
