//
//  Level1_2.swift
//  Favourite X
//
//  Created by Kumar, Vishnu | Vishnu | RMI on 2025/01/31.
//

import SwiftUI

struct Level1_2: View {
    @State private var buttonOffset: CGSize = .zero
    @State private var count = 1
    @State private var lost = false;
    @State private var proceedLevel = false;
    var body: some View {
        if (lost) { LoserView()}
        else if (proceedLevel) {Proceed_Screen()}
        else {
            HStack{
                Spacer()
                Text("Hearts left: \(count)/5")
                    .font(.title)
                    .foregroundStyle(.brown)
                    
                
                Spacer()
                Text("❌")
                    .padding()
                    .onTapGesture {
                        SoundManager.shared.playWinSound()
                        proceedLevel = true
                    }
            }
            
            VStack {
                Spacer()
                Text("Select the name of your favourite crush correctly:")
                    .font(.largeTitle)
                    .bold()
                    .padding(.bottom, 50)
                Text("Nora")
//                    .font(.largeTitle)
                    .font(.system(size: 15))
                    .bold()
                    .padding()
                    .padding(.horizontal, 20)
                    .background(LinearGradient(gradient: Gradient(colors: [Color.yellow, Color.orange]), startPoint: .leading, endPoint: .trailing))
                    .padding(.top, 120)
                    .clipShape(RoundedRectangle(cornerRadius: 15))
                    .offset(buttonOffset)
                
                    .onTapGesture {
                        SoundManager.shared.playButtonClickSound()
                        moveButtonToRandomLocation()
                        print(count)
                    }
                
                Spacer()
            }
        }
    }
    private func moveButtonToRandomLocation() {
            count+=1
            if (count >= 5) {
                SoundManager.shared.playLooseSound()
                lost = true
            }
            let randomX = CGFloat.random(in: -250...250)
            let randomY = CGFloat.random(in: -250...250)
            
            // Set the new position
            buttonOffset = CGSize(width: randomX, height: randomY)
        }
}

#Preview {
    Level1_2()
}
