import SwiftUI

struct ContentView: View {
    @State private var clickedPlay = false
    var body: some View {
        if clickedPlay {
            Level1()
        }
        else {
            VStack {
                Spacer()
                
                Image(systemName: "heart.fill")
                    .foregroundColor(.red)
                    .font(.system(size: 100))
                
                Text("Hello, Buddy!")
                    .font(.custom("Chalkduster", size: 40))
                    .bold()
                    .foregroundColor(.pink)
                
                Spacer()
                
                Text("Let's Start the Game")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.white)
                    .background(LinearGradient(gradient: Gradient(colors: [Color.pink, Color.purple]), startPoint: .top, endPoint: .bottom))
                    .cornerRadius(25)
                    .shadow(radius: 10)
                    .scaleEffect(1.1)
                    .onTapGesture{
                        SoundManager.shared.playButtonClickSound()
                        clickedPlay = true;
                    }
                
                    .padding(.horizontal, 50)
                    .padding(.bottom, 30)
            }
            .foregroundColor(.white)
            .padding()
        }
    }
    
}

#Preview {
    ContentView()
}
