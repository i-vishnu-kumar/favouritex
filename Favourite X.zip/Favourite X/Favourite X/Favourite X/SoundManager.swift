import AVFoundation

class SoundManager: ObservableObject {
    static let shared = SoundManager()
    
    private var player: AVAudioPlayer?
    private var isMusicPlaying = false

    private init() {}
    
    func playBackgroundMusic() {
        guard !isMusicPlaying else { return }
        
        if let soundURL = Bundle.main.url(forResource: "music", withExtension: "mp3") {
            do {
                player = try AVAudioPlayer(contentsOf: soundURL)
                player?.numberOfLoops = -1
                player?.play()
                isMusicPlaying = true
            } catch {
                print("Error playing music: \(error.localizedDescription)")
            }
        }
        else {
            print("Could not find the music file")
        }
    }
    
    func playButtonClickSound() {
            guard let soundURL = Bundle.main.url(forResource: "buttonclick", withExtension: "mp3") else {
                print("Error: buttonClick.mp3 not found in the bundle.")
                return
            }
            
            do {
                player = try AVAudioPlayer(contentsOf: soundURL)
                player?.play()
            } catch {
                print("Error playing button click sound: \(error.localizedDescription)")
            }
        }
    
    func playWinSound() {
            guard let soundURL = Bundle.main.url(forResource: "winner", withExtension: "mp3") else {
                print("Error: buttonClick.mp3 not found in the bundle.")
                return
            }
            
            do {
                player = try AVAudioPlayer(contentsOf: soundURL)
                player?.play()
            } catch {
                print("Error playing button click sound: \(error.localizedDescription)")
            }
        }
    
    func playLooseSound() {
            guard let soundURL = Bundle.main.url(forResource: "loss", withExtension: "mp3") else {
                print("Error: buttonClick.mp3 not found in the bundle.")
                return
            }
            
            do {
                player = try AVAudioPlayer(contentsOf: soundURL)
                player?.play()
            } catch {
                print("Error playing button click sound: \(error.localizedDescription)")
            }
        }
    
    func playWishesSound() {
            guard let soundURL = Bundle.main.url(forResource: "wishes", withExtension: "mp3") else {
                print("Error: buttonClick.mp3 not found in the bundle.")
                return
            }
            
            do {
                player = try AVAudioPlayer(contentsOf: soundURL)
                player?.play()
            } catch {
                print("Error playing button click sound: \(error.localizedDescription)")
            }
        }
    
    func stopBackgroundMusic() {
        player?.stop()
        isMusicPlaying = false
    }
}
