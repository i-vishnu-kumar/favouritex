import SwiftUI

struct Level1: View {
    @State private var correctWrong: String = ""
    @State private var wrongAnswerSelected: Bool = false
    @State private var showNextLevel = false
    @State private var passedLevel = false
    
    private let correctAnswer = "Nora"
    
    var body: some View {
        if showNextLevel{ Level1_2() }
        else if passedLevel{ Proceed_Screen() }
        else {
        HStack{
            Spacer()
            Text("❌")
                .padding()
        }.onTapGesture {
            SoundManager.shared.playWinSound()
            passedLevel = true
        }
            VStack {
                Spacer()
                Text("Select the name of your favourite crush correctly:")
                    .font(.largeTitle)
                    .bold()
                    .padding(.bottom, 20)
                
                HStack {
                    Spacer()
                    
                    Text("Katrina")
//                        .font(.largeTitle)
                        .font(.system(size: 15))
                        .bold()
                        .padding()
                        .padding(.horizontal, 20)
                        .background(LinearGradient(gradient: Gradient(colors: [Color.pink, Color.purple]), startPoint: .leading, endPoint: .trailing))
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .onTapGesture {
                            SoundManager.shared.playButtonClickSound()
                            checkAnswer(selectedAnswer: "Katrina")
                        }
                    
                    Spacer()
                    
                    Text("Nora")
//                        .font(.largeTitle)
                        .font(.system(size: 15))
                        .bold()
                        .padding()
                        .padding(.horizontal, 20)
                        .background(LinearGradient(gradient: Gradient(colors: [Color.yellow, Color.orange]), startPoint: .leading, endPoint: .trailing))
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .onTapGesture {
                            SoundManager.shared.playButtonClickSound()
                            checkAnswer(selectedAnswer: "Nora")
                            showNextLevel = true;
                        }
                    
                    Spacer()
                    
                    Text("Kriti")
//                        .font(.largeTitle)
                        .font(.system(size: 15))
                        .bold()
                        .padding()
                        .padding(.horizontal, 20)
                        .background(LinearGradient(gradient: Gradient(colors: [Color.red, Color.gray]), startPoint: .leading, endPoint: .trailing))
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .onTapGesture {
                            SoundManager.shared.playButtonClickSound()
                            checkAnswer(selectedAnswer: "Kriti")
                        }
                    
                    Spacer()
                }
                Spacer()
            }
            
            
            if wrongAnswerSelected {
                Text("Oops! You got it wrong 👎🏻")
                    .font(.system(size: 25))
//                    .font(.largeTitle)
                    .bold()
                    .padding()
                    .padding(.horizontal, 20)
                    .foregroundColor(.red)
            } else if correctWrong == "Correct" {
                Text("You got it right! 🎉")
                    .font(.largeTitle)
                    .bold()
                    .padding()
                    .padding(.horizontal, 20)
                    .foregroundColor(.green)
            }
            
            Spacer()
        }
    }
    
    func checkAnswer(selectedAnswer: String) {
        if selectedAnswer == correctAnswer {
            correctWrong = "Correct"
            wrongAnswerSelected = false
        } else {
            correctWrong = "Wrong"
            wrongAnswerSelected = true
        }
    }
}

#Preview {
    Level1()
}
