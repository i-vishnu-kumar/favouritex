//
//  Favourite_XTests.swift
//  Favourite XTests
//
//  Created by Kumar, Vishnu | Vishnu | RMI on 2025/01/31.
//

import Testing
@testable import Favourite_X

struct Favourite_XTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
