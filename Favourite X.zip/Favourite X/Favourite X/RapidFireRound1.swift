//
//  RapidFireRound1.swift
//  Favourite X
//
//  Created by Kumar, Vishnu | Vishnu | RMI on 2025/02/01.
//

import SwiftUI

struct RapidFireRound1: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    RapidFireRound1()
}
